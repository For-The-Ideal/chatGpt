import { createStore } from 'vuex'
export default createStore({
  state: {
    name: 'zhagnsan'
  }
})