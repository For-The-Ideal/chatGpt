export interface Reactive {
    isCollapsed:Boolean
  }