export interface Reactive {
    params: {
      userName: string;
      passWord: string;
    };
  }