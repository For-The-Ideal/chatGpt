<template>
  <div>
    
  </div>
</template>

<script>
export default {

}
</script>

<style scoped lang="less">
@import "./index.less";
</style>