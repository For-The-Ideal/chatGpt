<script setup lang="ts">
import Layout from "./layout/index.vue"
</script>

<template>
  <Layout>
    <router-view/>
  </Layout>
</template>

<style scoped>

</style>
