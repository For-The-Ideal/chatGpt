<script setup lang="ts">
import { ref } from 'vue'

defineProps<{ msg: string }>()

const count = ref(0)
</script>

<template>
 
</template>

<style scoped lang="less">
@import "./index.less";
</style>
